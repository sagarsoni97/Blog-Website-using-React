export const Variant = {
   success : "success",
   danger : "danger",
   warning : "warning"
  };
  